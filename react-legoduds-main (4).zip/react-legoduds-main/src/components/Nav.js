export default function Nav(){
    return (
        <nav>
            <a href="city.html">City</a>
            <a className="active" href="ninjago.html">Ninjago</a>
            <a href="castle-knights.html">Caste and Knights</a>
            <a href="marine-pirates.html">Marine and Pirates</a>
            <a href="movie-characters.html">Movie characters</a>
        </nav>
    )
}