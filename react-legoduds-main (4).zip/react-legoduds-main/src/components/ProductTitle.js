export default function ProductTitle({name}){
    return <h3>{name}</h3>

}