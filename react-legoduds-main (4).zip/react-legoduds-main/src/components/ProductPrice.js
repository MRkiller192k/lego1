export default function ProductPrice({price}){
    return <span>{price}</span>
}