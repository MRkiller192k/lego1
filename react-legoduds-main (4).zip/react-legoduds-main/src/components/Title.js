export default function Title(){
    return <h1>Ninjago</h1>
}