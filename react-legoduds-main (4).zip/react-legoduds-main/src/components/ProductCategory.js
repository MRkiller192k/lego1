export default function ProductCategory({cat}){
    return <span>{cat}</span>
}